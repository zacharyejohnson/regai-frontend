import React, { useState } from 'react';
import EditScoringLevelModal from './EditScoringLevelModal';

function ScoringLevelTable({ scoringLevels, onUpdate }) {
  const [editingLevel, setEditingLevel] = useState(null);

  const handleLevelUpdate = (index, updatedLevel) => {
    const newLevels = [...scoringLevels];
    newLevels[index] = updatedLevel;
    onUpdate(newLevels);
  };

  return (
    <div className="p-4">
      <table className="w-full border-collapse">
        <thead>
          <tr>
            <th className="border p-2">Level</th>
            <th className="border p-2">Score</th>
            <th className="border p-2">Description</th>
            <th className="border p-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {scoringLevels.map((level, index) => (
            <tr key={index}>
              <td className="border p-2">{level.name}</td>
              <td className="border p-2">{level.score}</td>
              <td className="border p-2">{level.description}</td>
              <td className="border p-2">
                <button
                  className="bg-blue-500 text-white px-2 py-1 rounded"
                  onClick={() => setEditingLevel(index)}
                >
                  Edit
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {editingLevel !== null && (
        <EditScoringLevelModal
          level={scoringLevels[editingLevel]}
          onSave={(updatedLevel) => {
            handleLevelUpdate(editingLevel, updatedLevel);
            setEditingLevel(null);
          }}
          onCancel={() => setEditingLevel(null)}
        />
      )}
    </div>
  );
}

export default ScoringLevelTable;