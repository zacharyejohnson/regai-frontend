import React, { useState } from 'react';
import ScoringLevelTable from './ScoringLevelTable';

function RubricCategory({ category, onUpdate }) {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleScoringLevelsUpdate = (updatedLevels) => {
    onUpdate({...category, scoring_levels: updatedLevels});
  };

  return (
    <div className="border rounded-lg overflow-hidden">
      <button
        className="w-full bg-gray-100 p-4 text-left font-semibold flex justify-between items-center"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <span>{category.category} ({category.weight}%)</span>
        <span>{isExpanded ? '▲' : '▼'}</span>
      </button>
      {isExpanded && (
        <ScoringLevelTable
          scoringLevels={category.scoring_levels}
          onUpdate={handleScoringLevelsUpdate}
        />
      )}
    </div>
  );
}

export default RubricCategory;