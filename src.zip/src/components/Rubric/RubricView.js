import React from 'react';
import RubricCategory from './RubricCategory';

function RubricView({ rubric, onRubricUpdate }) {
  const handleCategoryUpdate = (index, updatedCategory) => {
    const newRubric = [...rubric];
    newRubric[index] = updatedCategory;
    onRubricUpdate(newRubric);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Rubric</h2>
      <div className="space-y-4">
        {rubric.map((category, index) => (
          <RubricCategory
            key={index}
            category={category}
            onUpdate={(updatedCategory) => handleCategoryUpdate(index, updatedCategory)}
          />
        ))}
      </div>
    </div>
  );
}

export default RubricView;