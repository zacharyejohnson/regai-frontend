import React, { useState, useRef } from 'react';
import { PencilIcon } from '@heroicons/react/solid';

function RubricDisplay({ rubric, onEditRubric }) {
  const [hoveredCell, setHoveredCell] = useState(null);
  const popoutRef = useRef(null);

  const maxLevels = Math.max(...rubric.map(category => category.scoring_levels.length));

  const truncateText = (text, maxWords) => {
    const words = text.split(' ');
    if (words.length <= maxWords) return text;
    return words.slice(0, maxWords).join(' ') + '...';
  };

  const handleCellHover = (event, row, col) => {
    const cellRect = event.currentTarget.getBoundingClientRect();
    setHoveredCell({ row, col, rect: cellRect });
  };

  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Rubric</h2>
        <button
          onClick={() => onEditRubric(rubric)}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded inline-flex items-center"
        >
          <PencilIcon className="h-5 w-5 mr-2" />
          Edit Rubric
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </th>
              {[...Array(maxLevels)].map((_, index) => (
                <th key={index} className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Level {index + 1}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {rubric.map((category, rowIndex) => (
              <tr key={category.category}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {category.category} ({category.weight}%)
                </td>
                {[...Array(maxLevels)].map((_, colIndex) => {
                  const level = category.scoring_levels[colIndex];
                  return (
                    <td
                      key={colIndex}
                      className="px-6 py-4 text-sm text-gray-500 relative"
                      onMouseEnter={(e) => handleCellHover(e, rowIndex, colIndex)}
                      onMouseLeave={() => setHoveredCell(null)}
                    >
                      {level && truncateText(level.description, 30)}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {hoveredCell && (
        <div
          ref={popoutRef}
          className="fixed z-50 bg-white border border-gray-200 p-4 rounded shadow-lg max-w-md"
          style={{
            top: `${hoveredCell.rect.bottom}px`,
            left: `${hoveredCell.rect.left}px`,
          }}
        >
          <h4 className="font-bold">{rubric[hoveredCell.row].scoring_levels[hoveredCell.col].name}</h4>
          <p>{rubric[hoveredCell.row].scoring_levels[hoveredCell.col].description}</p>
        </div>
      )}
    </div>
  );
}

export default RubricDisplay;