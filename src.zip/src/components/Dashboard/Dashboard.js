import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { API_BASE_URL } from '../utils/api'
import AssignmentCard from './AssignmentCard';
import CreateAssignmentModal from './CreateAssignmentModal';
import Pagination from './Pagination';
import Button from '../Common/Button';

function Dashboard() {
  const [assignments, setAssignments] = useState([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    fetchAssignments();
  }, [currentPage]);

  const fetchAssignments = () => {
  axios.get(`${API_BASE_URL}/assignments/?page=${currentPage}`)
    .then(response => {
      setAssignments(response.data.results || []);
      setTotalPages(Math.ceil((response.data.count || 0) / 9));
    })
    .catch(error => {
      console.error('Error fetching assignments:', error);
      setAssignments([]);
      setTotalPages(1);
    });
};
  const handleCreateAssignment = (newAssignment) => {
  axios.post(`${API_BASE_URL}/assignments/`, newAssignment)
    .then(response => {
      setAssignments([response.data, ...assignments]);
      setShowCreateModal(false);
    })
    .catch(error => {
      console.error('Error creating assignment:', error.response ? error.response.data : error.message);
      // Handle the error appropriately in your UI
    });
};

const handleDeleteAssignment = (id) => {
  if (window.confirm('Are you sure you want to delete this assignment?')) {
    axios.delete(`${API_BASE_URL}/assignments/${id}/`)
      .then(() => {
        setAssignments(assignments.filter(a => a.id !== id));
      })
      .catch(error => {
        console.error('Error deleting assignment:', error.response ? error.response.data : error.message);
        // Handle the error appropriately in your UI
      });
  }
};
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Assignments</h1>
        <Button onClick={() => setShowCreateModal(true)}>
          Create Assignment
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {assignments.map(assignment => (
          <AssignmentCard
            key={assignment.id}
            assignment={assignment}
            onDelete={handleDeleteAssignment}
          />
        ))}
      </div>

      <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
      />

      {showCreateModal && (
        <CreateAssignmentModal
          onClose={() => setShowCreateModal(false)}
          onCreate={handleCreateAssignment}
        />
      )}
    </div>
  );
}

export default Dashboard;