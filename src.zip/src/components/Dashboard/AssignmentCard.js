import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../Common/Button';

function AssignmentCard({ assignment, onDelete }) {
  return (
    <div className="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
      <div className="px-4 py-5 sm:p-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100">
          {assignment.title}
        </h3>
        <div className="mt-2 max-w-xl text-sm text-gray-500 dark:text-gray-400">
          <p>{assignment.description.substring(0, 100)}...</p>
        </div>
        <div className="mt-5 flex items-center justify-between">
          <Link
            to={`/assignment/${assignment.id}`}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            View Details
          </Link>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {assignment.submission_count} submissions
          </span>
        </div>
      </div>
      <div className="px-4 py-4 sm:px-6 bg-gray-50 dark:bg-gray-700">
        <Button
          onClick={() => onDelete(assignment.id)}
          variant="danger"
          fullWidth
        >
          Delete Assignment
        </Button>
      </div>
    </div>
  );
}

export default AssignmentCard;