import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {API_BASE_URL} from '../utils/api';

function KnowledgeBase() {
  const [knowledgeBaseItems, setKnowledgeBaseItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    // Temporarily comment out the API call until the endpoint is implemented
    // fetchKnowledgeBaseItems();
  }, []);

  const fetchKnowledgeBaseItems = () => {
    axios.get(`${API_BASE_URL}/knowledge-base/`)
      .then(response => setKnowledgeBaseItems(response.data))
      .catch(error => console.error('Error fetching knowledge base items:', error));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    // Implement search functionality when the API is ready
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Knowledge Base</h1>
      <p>Knowledge base content will be displayed here once the API is implemented.</p>
    </div>
  );
}

export default KnowledgeBase;