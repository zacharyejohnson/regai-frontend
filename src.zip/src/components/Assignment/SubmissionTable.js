import React, { useState } from 'react';
import { ChevronDownIcon, ChevronUpIcon, TrashIcon, EyeIcon } from '@heroicons/react/solid';

function CircularProgressBar({ percentage }) {
  const circumference = 2 * Math.PI * 20; // radius is 20
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  const getColor = (percent) => {
    if (percent >= 80) return '#10B981'; // green
    if (percent >= 60) return '#FBBF24'; // yellow
    return '#EF4444'; // red
  };

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg className="w-12 h-12" viewBox="0 0 44 44">
        <circle
          className="text-gray-200"
          stroke="currentColor"
          strokeWidth="4"
          fill="transparent"
          r="20"
          cx="22"
          cy="22"
        />
        <circle
          className="text-blue-600"
          stroke={getColor(percentage)}
          strokeWidth="4"
          strokeLinecap="round"
          fill="transparent"
          r="20"
          cx="22"
          cy="22"
          style={{
            strokeDasharray: circumference,
            strokeDashoffset: strokeDashoffset,
            transition: 'stroke-dashoffset 0.5s ease 0s',
          }}
        />
      </svg>
      <span className="absolute text-xs font-semibold text-gray-700">{percentage}%</span>
    </div>
  );
}

function SubmissionTable({ submissions, onDeleteSubmission }) {
  const [expandedSubmission, setExpandedSubmission] = useState(null);

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white">
        <thead>
          <tr>
            <th className="px-4 py-3 border-b-2 border-gray-300 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
              Student Name
            </th>
            <th className="px-4 py-3 border-b-2 border-gray-300 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
              Grade
            </th>
            <th className="px-4 py-3 border-b-2 border-gray-300 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white">
          {submissions.map((submission) => (
            <React.Fragment key={submission.id}>
              <tr>
                <td className="px-4 py-4 whitespace-no-wrap border-b border-gray-500">
                  {submission.student_name}
                </td>
                <td className="px-4 py-4 whitespace-no-wrap border-b border-gray-500">
                  <CircularProgressBar percentage={Math.round(submission.grade * 100)} />
                </td>
                <td className="px-4 py-4 whitespace-no-wrap border-b border-gray-500">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setExpandedSubmission(expandedSubmission === submission.id ? null : submission.id)}
                      className="p-1 rounded-full text-indigo-600 hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                      title={expandedSubmission === submission.id ? "Hide Details" : "Show Details"}
                    >
                      {expandedSubmission === submission.id ? (
                        <ChevronUpIcon className="h-5 w-5" aria-hidden="true" />
                      ) : (
                        <ChevronDownIcon className="h-5 w-5" aria-hidden="true" />
                      )}
                    </button>
                    <button
                      onClick={() => onDeleteSubmission(submission.id)}
                      className="p-1 rounded-full text-red-600 hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                      title="Delete Submission"
                    >
                      <TrashIcon className="h-5 w-5" aria-hidden="true" />
                    </button>
                  </div>
                </td>
              </tr>
              {expandedSubmission === submission.id && (
                <tr>
                  <td colSpan="3" className="px-4 py-4 whitespace-no-wrap border-b border-gray-500">
                    <div className="ml-4 space-y-4">
                      <h4 className="font-bold text-lg">Detailed Scores:</h4>
                      {submission.category_scores && submission.category_scores.map((category, index) => (
                        <div key={index} className="bg-gray-100 p-4 rounded-lg">
                          <h5 className="font-semibold text-md mb-2">{category.category}</h5>
                          <p><strong>Score:</strong> {category.score}</p>
                          <p><strong>Weight:</strong> {category.weight}%</p>
                          <p className="mt-2"><strong>Justification:</strong> {category.justification}</p>
                        </div>
                      ))}
                      {submission.overall_score_justification && (
                        <div className="bg-gray-100 p-4 rounded-lg">
                          <h5 className="font-semibold text-md mb-2">Overall Justification:</h5>
                          <p>{submission.overall_score_justification}</p>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default SubmissionTable;