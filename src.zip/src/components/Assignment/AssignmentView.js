import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { API_BASE_URL } from '../utils/api';
import RubricDisplay from '../Rubric/RubricDisplay';
import RubricEditModal from '../Rubric/RubricEditModal';
import SubmissionTable from './SubmissionTable';
import { CloudUploadIcon } from '@heroicons/react/solid';

function AssignmentView() {
  const { id } = useParams();
  const [assignment, setAssignment] = useState(null);
  const [submissions, setSubmissions] = useState([]);
  const [showRubricEditModal, setShowRubricEditModal] = useState(false);

  useEffect(() => {
    fetchAssignment();
    fetchSubmissions();
  }, [id]);

  const fetchAssignment = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/assignments/${id}/`);
      setAssignment(response.data);
    } catch (error) {
      console.error('Error fetching assignment:', error);
    }
  };

  const fetchSubmissions = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/assignments/${id}/submissions/`);
      setSubmissions(response.data);
    } catch (error) {
      console.error('Error fetching submissions:', error);
    }
  };

  const handleRubricUpdate = async (updatedRubric) => {
    try {
      await axios.patch(`${API_BASE_URL}/assignments/${id}/`, { rubric: updatedRubric });
      setAssignment({ ...assignment, rubric: updatedRubric });
      setShowRubricEditModal(false);
    } catch (error) {
      console.error('Error updating rubric:', error);
    }
  };

  const handleSubmitClick = () => {
      document.getElementById('file-upload').click();
    };

  const handleDeleteSubmission = async (submissionId) => {
    try {
      await axios.delete(`${API_BASE_URL}/submissions/${submissionId}/`);
      fetchSubmissions();
    } catch (error) {
      console.error('Error deleting submission:', error);
    }
  };


  const handleFileUpload = async (event) => {
    const files = event.target.files;
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      await axios.post(`${API_BASE_URL}/assignments/${id}/submit/`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      fetchSubmissions();
    } catch (error) {
      console.error('Error uploading files:', error);
    }
  };

  if (!assignment) return <div>Loading...</div>;

  return (
      <div className="max-w-6xl mx-auto p-4">
        <h1 className="text-3xl font-bold mb-4">{assignment.title}</h1>
        <p className="mb-6">{assignment.description}</p>

        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-4">Submit Assignments</h2>
          <div className="flex items-center">
            <input
                id="file-upload"
                type="file"
                multiple
                accept=".pdf,.docx,.txt"
                onChange={handleFileUpload}
                className="hidden"
            />
            <button
                onClick={handleSubmitClick}
                className="flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <CloudUploadIcon className="mr-2 h-5 w-5"/>
              Upload Files
            </button>
            <span className="ml-3 text-sm text-gray-500">
            Upload .pdf, .docx, or .txt files
          </span>
          </div>
        </div>

        <RubricDisplay
            rubric={assignment.rubric}
            onEditRubric={() => setShowRubricEditModal(true)}
        />

        {showRubricEditModal && (
            <RubricEditModal
                rubric={assignment.rubric}
                onSave={handleRubricUpdate}
                onClose={() => setShowRubricEditModal(false)}
            />
        )}

        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Submissions</h2>
          <SubmissionTable
              submissions={submissions}
              onDeleteSubmission={handleDeleteSubmission}
          />
        </div>
      </div>
  );
}

export default AssignmentView;