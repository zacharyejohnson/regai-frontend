const getBackendPath = () => {
  if (process.env.NODE_ENV === 'development') {
    return 'http://localhost:8000/api';
  }
  // For production, you might want to use an environment variable
  // return process.env.REACT_APP_API_URL;
  return '/api'; // Fallback to relative path for production
};

export const API_BASE_URL = getBackendPath();