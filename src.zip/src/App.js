import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout/Layout';
import Dashboard from './components/Dashboard/Dashboard';
import AssignmentView from './components/Assignment/AssignmentView';
import RubricEditor from './components/Rubric/RubricEditor';
import SubmissionList from './components/Submission/SubmissionList';
import GradingPipeline from './components/Grading/GradingPipeline';
import KnowledgeBase from './components/KnowledgeBase/KnowledgeBase';

function App() {
  return (
    <ThemeProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/assignment/:id" element={<AssignmentView />} />
            <Route path="/assignment/:id/rubric" element={<RubricEditor />} />
            <Route path="/assignment/:id/submissions" element={<SubmissionList />} />
            <Route path="/submission/:id/grade" element={<GradingPipeline />} />
            <Route path="/knowledge-base" element={<KnowledgeBase />} />
          </Routes>
        </Layout>
      </Router>
    </ThemeProvider>
  );
}

export default App;